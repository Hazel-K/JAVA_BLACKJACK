package blog.hyojin4588.blackjack;

public class Card {

	// 멤버 필드
	public static final String[] PATTERNS = { "♠", "♣", "◆", "♥" };
	private String pattern;
	private String denomination;
	// 멤버 필드

	// 생성자
	public Card(String pattern, String denomination) {
		this.pattern = pattern;
		this.denomination = denomination;
	}
	// 생성자

	// 게터
	public String getPattern() {
		return pattern;
	}

	public String getDenomination() {
		return denomination;
	}
	// 게터

	// 객체 메소드
	@Override
	public String toString() {
		return String.format("%s %s", pattern, denomination);
	}
	// 객체 메소드

}
